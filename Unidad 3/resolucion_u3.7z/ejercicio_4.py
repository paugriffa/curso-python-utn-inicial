

sexo="M"
edad=66

if sexo=="M" and edad>=18 and edad<=65:
    print("Estás en edad de trabajar")
else:
    print("No estás en edad de trabajar")